#!/sbin/sh
# Init TWRP recovery TWRP shell script --==ViT==-- 2019-12-25
# This script will add additional partitions into /etc/twrp.fstab 
echo $(date +%F' '%H:%M:%S) - Script add partitions into /etc/twrp.fstab script started.... > /tmp/inittwrp.log
if [ -f /etc/twrp.fstab ]
then 
 /sbin/bash cp /etc/twrp.fstab /etc/twrp.fstab.orig
fi
echo '# Additional partition from script start line' >> /etc/twrp.fstab
awk 'NR>1 { print $4 }'  /proc/inand |  tr -d \" | sort | grep -Ev "system|data|cache|boot|recovery|logo|bootloader|tee|vendor|odm|param|product|metadata" | while read line; do echo -e '/'$line"\t"'emmc'"\t"'/dev/block/'$line"\t"'flags=backup=1'>> /etc/twrp.fstab; done
grep -q tee /proc/inand && ls -a /dev/block | grep tee &&           echo '/tee            ext4    /dev/block/tee         flags=backup=1' >> /etc/twrp.fstab
grep -q vendor /proc/inand && ls -a /dev/block | grep vendor &&     echo '/vendor         ext4    /dev/block/vendor      flags=backup=1;display=Vendor' >> /etc/twrp.fstab
grep -q vendor /proc/inand && ls -a /dev/block | grep vendor &&     echo '/vendor_image	  emmc	  /dev/block/vendor      flags=backup=1;display=VendorImg;flashimg' >> /etc/twrp.fstab
grep -q odm /proc/inand && ls -a /dev/block | grep odm &&           echo '/odm            ext4    /dev/block/odm         flags=backup=1' >> /etc/twrp.fstab
grep -q param /proc/inand && ls -a /dev/block | grep param &&       echo '/param          ext4    /dev/block/param       flags=backup=1' >> /etc/twrp.fstab
grep -q product /proc/inand && ls -a /dev/block | grep product &&   echo '/product        ext4    /dev/block/product     flags=backup=1' >> /etc/twrp.fstab
grep -q metadata /proc/inand && ls -a /dev/block | grep metadata && echo '/metadata       ext4    /dev/block/metadata    flags=backup=1' >> /etc/twrp.fstab
echo '# Additional partition from script end line' >> /etc/twrp.fstab
echo $(date +%F' '%H:%M:%S) - Script add partitions into /etc/twrp.fstab script ended.... > /tmp/inittwrp.log
exit 0

