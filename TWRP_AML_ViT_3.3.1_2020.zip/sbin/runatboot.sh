#!/sbin/sh
# Startup TWRP shell script --==ViT==-- 2019-12-25
# This script check runaboot.sh file from int/ext sdcard or ext USB drive from root TWRP folder
# If runaboot.sh will found on user space device 
# then this script will be executed from /tmp folder TWRP recovery
echo $(date +%F' '%H:%M:%S) - TWRP script /sbin/runaboot.sh started.... > /tmp/runatboot.log
if [ -f /sdcard/TWRP/runatboot.sh ]
    then file_exec=/sdcard/TWRP/runatboot.sh
elif [ -f /external_sd/TWRP/runatboot.sh ]
    then file_exec=/external_sd/TWRP/runatboot.sh
elif [ -f /usb-otg/TWRP/runatboot.sh ]
    then file_exec=/usb-otg/TWRP/runatboot.sh
else    
    echo - User script runatboot.sh not found on user space devices >> /tmp/runatboot.log
    exit 0
fi
echo $(date +%F' '%H:%M:%S) - User script $file_exec found on user space devices >> /tmp/runatboot.log
cp $file_exec /tmp/runatboot.sh
chmod 755 /tmp/runatboot.sh
/tmp/runatboot.sh
echo $(date +%F' '%H:%M:%S) - User script $file_exec executed from /tmp/ folder >> /tmp/runatboot.log
