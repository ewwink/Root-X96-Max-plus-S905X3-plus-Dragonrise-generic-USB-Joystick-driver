#!/sbin/sh
# Init TWRP recovery TWRP shell script --==ViT==-- 2019-12-25
# This script check inittwrp.sh file from int/ext sdcard or ext USB drive from root TWRP folder
# If inittwrp.sh will found on user space device 
# then this script will be executed before run main TWRP from /tmp folder TWRP recovery
echo $(date +%F' '%H:%M:%S) - TWRP script /sbin/inittwrp.sh started.... > /tmp/inittwrp.log
if [ -f /sdcard/TWRP/inittwrp.sh ]
    then file_exec=/sdcard/TWRP/inittwrp.sh
elif [ -f /external_sd/TWRP/inittwrp.sh ]
    then file_exec=/external_sd/TWRP/inittwrp.sh
elif [ -f /usb-otg/TWRP/inittwrp.sh ]
    then file_exec=/usb-otg/TWRP/inittwrp.sh
else    
    echo - User script inittwrp.sh not found on user space devices >> /tmp/inittwrp.log
    exit 0
fi
echo $(date +%F' '%H:%M:%S) - User script $file_exec found on user space devices >> /tmp/inittwrp.log
cp $file_exec /tmp/inittwrp.sh
chmod 755 /tmp/inittwrp.sh
/tmp/inittwrp.sh
echo $(date +%F' '%H:%M:%S) - User script $file_exec executed from /tmp/ folder >> /tmp/inittwrp.log
